﻿namespace dataType
{
    public class date
    {
    }
}